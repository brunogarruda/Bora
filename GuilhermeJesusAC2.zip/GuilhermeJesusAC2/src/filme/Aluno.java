package filme;

public class Aluno {
	// Atributos
	private int ra;
	private String nome;
	private double nota;
	
	// Construtor
	public Aluno(int ra, String nome, double nota) {
		this.ra = ra;
		this.nome = nome;
		this.nota = nota;
	}

	// Getters e Setters
	public int getRa() {
		return ra;
	}

	public void setRa(int ra) {
		this.ra = ra;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public double getNota() {
		return nota;
	}

	public void setNota(double nota) {
		this.nota = nota;
	}

	// M�todo toString()
	@Override
	public String toString() {
		return "Aluno [ra=" + ra + ", nome=" + nome + ", nota=" + nota + "]";
	}
	
	

}
