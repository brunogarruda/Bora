package filme;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Formatter;
import java.util.FormatterClosedException;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class ProgramaFilme {

	public static void gravaArquivo(ListaObj<Filme> lista, boolean isCSV) {
		FileWriter arq = null;
		Formatter saida = null;
		boolean deuRuim = false;
		String nomeArquivo;

		if (isCSV) {
			nomeArquivo = "filme.csv";
		} else {
			nomeArquivo = "filme.txt";
		}

		try {
			arq = new FileWriter(nomeArquivo, true);
			saida = new Formatter(arq);
		} catch (IOException erro) {
			System.err.println("Erro ao abrir arquivo.");
			System.exit(1);
		}

		try {

			for (int i = 0; i < lista.getTamanho(); i++) {
				Filme f = lista.getElemento(i);

				if (isCSV) {
					saida.format("%d;%s;%.2f;%s;%d", f.getIdFilme(), f.getNome(), f.getNota(), f.getGenero(),
							f.getIdade());
				} else {
					saida.format("%d %s %.2f %s %d", f.getIdFilme(), f.getNome(), f.getNota(), f.getGenero(),
							f.getIdade());
				}
			}
		} catch (FormatterClosedException erro) {
			System.err.println("Erro ao gravar no arquivo.");
			deuRuim = true;
		} finally {
			saida.close();
			try {
				arq.close();
			} catch (IOException erro) {
				System.err.println("Erro ao fechar arquivo.");
				deuRuim = true;
			}
			if (deuRuim) {
				System.exit(1);
			}
		}
	}

	public static void leExibeArquivo(boolean isCSV) {
		FileReader arq = null; // objeto FileReader - representa o arquivo a ser lido
		Scanner entrada = null; // objeto Scanner - para ler do arquivo
		String nomeArquivo; // nome do arquivo
		boolean deuRuim = false; // indica se deu erro

		if (isCSV) {
			nomeArquivo = "filme.csv"; // nome do arquivo, se for CSV
		} else {
			nomeArquivo = "filme.txt"; // nome do arquivo, se for TXT
		}

		// Abre o arquivo para leitura
		try {
			arq = new FileReader(nomeArquivo);
			if (isCSV) {
				// se o arquivo for CSV, usa como delimitador de campo o ';' e o fim de registro
				entrada = new Scanner(arq).useDelimiter(";|\\r\\n");
			} else {
				// se o arquivo for TXT, usa como delimitador de campo o ' ' e o fim de registro
				entrada = new Scanner(arq);
			}
		} catch (FileNotFoundException erro) {
			System.err.println("Arquivo n�o encontrado");
			System.exit(1); // encerra o programa, com status de erro
		}

		// L� os registros do arquivo e exibe os dados lidos na console
		try {
			// Exibe na console os t�tulos das colunas
			System.out.printf("%-10s%-10s%8s%8s%7s\n", "ID", "NOME", "NOTA", "GENERO", "IDADE");
			// Enquanto tem registro a ser lido
			while (entrada.hasNext()) {
				int codigo = entrada.nextInt();
				String nome = entrada.next();
				double nota = entrada.nextDouble();
				String genero = entrada.next();
				int idade = entrada.nextInt();
				System.out.printf("%-10d%-10s%7.2f%10s%7d\n", codigo, nome, nota, genero, idade); // Exibe na console em
																									// colunas
			}
		} catch (NoSuchElementException erro) {
			System.err.println("Arquivo com problemas.");
			deuRuim = true;
		} catch (IllegalStateException erro) {
			System.err.println("Erro na leitura do arquivo.");
			deuRuim = true;
		} finally {
			entrada.close();
			try {
				arq.close();
			} catch (IOException erro) {
				System.err.println("Erro ao fechar arquivo.");
				deuRuim = true;
			}
			if (deuRuim) {
				System.exit(1);
			}
		}
	}

	public static void main(String[] args) {
		ListaObj<Filme> lista = new ListaObj<Filme>(10);
		Scanner leitor = new Scanner(System.in);

		boolean fim = false;

		while (!fim) {
			System.out.println("\nAdicionar filme: aperte 1" + "\nExibir a lista de filme: aperte 2"
					+ "\nGravar a lista em arquivo: aperte 3" + "\nLer e exibir o arquivo: aperte 4"
					+ "\nGravar apenas filmes de um determinado genero em arquivo: aperte 5"
					+ "\nLer o arquivo e armazenar em lista: aperte 6" + "\nSair: aperte 7");
			int numero = leitor.nextInt();
			switch (numero) {
			case 1:
				double nota = 0;
				System.out.println("Adicione um filme");
				System.out.println("Digite o codigo do filme");
				int codigo = leitor.nextInt();
				// leitor = new Scanner(System.in);

				System.out.println("Digite o nome do filme");
				String nome = leitor.next();

				System.out.println("Digite a nota do filme");
				nota = leitor.nextDouble();
				while (nota < 0 || nota > 10) {
					System.out.println("Digite a nota do filme");
					nota = leitor.nextDouble();
				}

				System.out.println("Digite o genero do filme");
				String genero = leitor.next();

				System.out.println("Digite a idade do filme");
				int idade = leitor.nextInt();

				lista.adiciona(new Filme(codigo, nome, nota, genero, idade));
				System.out.println(new Filme(codigo, nome, nota, genero, idade));
				break;
			case 2:
				lista.exibe();
				break;
			case 3:
				gravaArquivo(lista, true);
				break;
			case 4:
				leExibeArquivo(true);
				break;
			case 5:
				if (lista.getTamanho() == 0) {
					System.out.println("Lista vazia. N�o h� nada para gravar.");
				} else {
					System.out.println("Digite o genero do filme");
					Filme filme = new Filme();
					genero = leitor.next();
					filme.setGenero(genero);
					filme.getGenero();

					lista.busca(filme);
					lista.adiciona(filme);
					System.out.println(filme);
					gravaArquivo(lista, false);
					lista.limpa();
				}
				break;
			case 6:
				ListaObj<Filme> lista2 = new ListaObj<Filme>(10);
				leExibeArquivo(false);
				
				Filme filme = new Filme();
				lista2.busca(filme);
				lista2.adiciona(filme);
				lista2.exibe();
				//leExibeArquivo(false);
				break;
			case 7:
				fim = true;
				break;

			default:
				break;
			}

		}

	}
}
